package com.engenhariadesoftware.t2;

import java.util.List;

public final class AtualizarTabela {
    public static void executar(List<String[]> tabela, double taxa) {

        for (int i = 1; i < tabela.size(); i++) {
            String resultado = tabela.get(i)[0] + ";";
            for (int j = 1; j < tabela.get(i).length; j++) {
                tabela.get(i)[j].replace(",", ".");
                if (tabela.get(i)[j].contains("FP =")) {

                    resultado += RecalcularCelula.executar(tabela.get(i)[j], taxa);
                    resultado = resultado.replace('.', ',');
                } else {

                    resultado += RecalcularCelula.executar(tabela.get(i)[j], taxa);
                    resultado = resultado.replace('.', ',');
                }
            }
            tabela.set(i, resultado.split(";"));
        }
    }
}
