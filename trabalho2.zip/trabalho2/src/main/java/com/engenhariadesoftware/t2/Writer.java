package com.engenhariadesoftware.t2;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Writer {
    public static void escrever(String caminho, String texto) {
        try {
            FileWriter arquivo = new FileWriter(caminho);
            PrintWriter gravarArq = new PrintWriter(arquivo);

            gravarArq.println(texto);

            gravarArq.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
