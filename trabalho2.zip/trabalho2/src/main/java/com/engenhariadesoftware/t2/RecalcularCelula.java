package com.engenhariadesoftware.t2;

public final class RecalcularCelula {
    public static String executar(String celula, double taxa) {
        System.out.println(celula);
        String spl1 = celula.substring(5, celula.indexOf("V") - 1);
        String spl2 = celula.substring(celula.indexOf("V") + 4, celula.length());

        spl1 = spl1.replace(',', '.');
        spl2 = spl2.replace(',', '.');

        return "FP = " + String.format("%.2f", (Double.parseDouble(spl1)) * taxa) + " FV = "
                + String.format("%.2f", (Double.parseDouble(spl2) * taxa));

    }
}
