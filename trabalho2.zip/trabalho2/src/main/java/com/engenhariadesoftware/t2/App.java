package com.engenhariadesoftware.t2;

import java.util.List;

public class App {
    public static void main(String[] args) {

        if (args[0] == null || !args[0].substring(args[0].length() - 4, args[0].length()).equals(".csv")) {
            System.out.println("O arquivo informado não é um csv");
            System.out.println("Exemplo para aumentar 50% do valor abaixo: ");
            System.out.println("java -cp atualizadordetaxa-1.0.jar com.rmflores.App tabela_rm.csv 50");
            System.exit(0);
        }

        if (args[1] == null) {
            System.out.println("Valor de aumento não informado");
            System.out.println("Exemplo para aumentar 50% do valor abaixo: ");
            System.out.println("java -cp atualizadordetaxa-1.0.jar com.rmflores.App tabela_rm.csv 50");
            System.exit(0);
        }

        double taxa = extracted(args[1]);

        List<String[]> table = Reader.ler(args[0]);

        AtualizarTabela.executar(table, taxa);

        table.stream().forEach(row -> System.out.println(row));

        Writer.escrever("tabela_rm" + "_" + args[1] + "%.csv", FormataCsv.executar(table));

        System.out.println("O arquivo " + "tabela_rm" + "_" + args[1] + "%.csv" + " foi gerado com SUCESSO");
    }

    public static double extracted(String args) {
        double taxa = 1 + (Double.parseDouble(args) / 100);
        return taxa;
    }
}
