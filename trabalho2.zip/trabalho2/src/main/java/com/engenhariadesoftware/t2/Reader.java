package com.engenhariadesoftware.t2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public final class Reader {

    public static List<String[]> ler(String file) {
        BufferedReader reader = null;
        String line = "";

        List<String[]> table = new ArrayList<>();
        String[] row = null;
        try {
            reader = new BufferedReader(new FileReader(file));
            int count = 1;
            String concat = "";
            while ((line = reader.readLine()) != null) {
                if (count == 1) {
                    row = line.split(",\"");
                    for (int i = 0; i < row.length; i++) {
                        row[i] = row[i].replace("\"", "");

                    }
                    table.add(row);
                } else {
                    concat += line;
                }

                if (count != 1 && line.substring(line.length() - 1, line.length()).equals("\"")) {
                    row = concat.split(",\"");
                    for (int i = 0; i < row.length; i++) {
                        row[i] = row[i].replace("\"", "");
                    }

                    table.add(row);
                    concat = "";
                }

                count++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return table;
    }
}
