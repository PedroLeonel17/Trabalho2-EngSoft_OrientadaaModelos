package com.engenhariadesoftware.t2;

import java.util.List;

public final class FormataCsv {
    public static String executar(List<String[]> tabela) {
        String resposta = "";

        for (int i = 0; i < tabela.get(0).length; i++) {
            if (i == 0)
                resposta += tabela.get(0)[i] + ",\"";
            else if (i == tabela.get(0).length - 1)
                resposta += tabela.get(0)[i] + "\"\n";
            else
                resposta += tabela.get(0)[i] + "\",\"";
        }

        resposta = resposta.replaceAll("AtÃ©", "Até");

        for (int i = 1; i < tabela.size(); i++) {
            for (int j = 0; j < tabela.get(i).length; j++) {
                if (j == 0) {
                    tabela.get(i)[j] = tabela.get(i)[j].replaceFirst("[(]", "\n\n(");
                } else
                    tabela.get(i)[j] = tabela.get(i)[j].replace("FV =", "\n\nFV =");

                if (j == tabela.get(i).length)
                    resposta += "\"" + tabela.get(i)[j] + "\"";
                else if (j == tabela.get(i).length - 1)
                    resposta += "\"" + tabela.get(i)[j] + "\"";
                else
                    resposta += "\"" + tabela.get(i)[j] + "\",";
            }
            resposta += "\n";
        }

        return resposta;
    }
}
