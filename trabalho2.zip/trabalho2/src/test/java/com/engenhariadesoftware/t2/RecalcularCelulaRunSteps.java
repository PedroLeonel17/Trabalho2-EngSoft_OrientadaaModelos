package com.engenhariadesoftware.t2;

import static org.junit.Assert.assertEquals;

import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class RecalcularCelulaRunSteps {
    private String total;
    private String acrescimo;
    private double taxa;

    private RecalcularCelula recalcularCelula;

    @Before
    private void init() {
        total = "";
        acrescimo = "";
        taxa = 0.0;
    }

    @Given("Uma celula com os valores de frete peso e frete valor")
    public void iniciaORecalculador() throws Throwable {
        recalcularCelula = new RecalcularCelula();
    }

    @When("Eu adiciono um acrescimo de {double} na celula {string}")
    public void recalcular(double taxa, String celula) {
        total = recalcularCelula.executar(celula, taxa);
    }

    @Then("Os valores desta devem ser atualizados para {string}")
    public void TestaValor(String celulaResultante) {
        assertEquals(total, celulaResultante);
    }

    @Given("Um valor de {string}")
    public void umValorDe(String s) {
        acrescimo = s;
    }

    @When("solicito a conversao")
    public void solicitoAConversao() {
        taxa = App.extracted(acrescimo);
    }

    @Then("O valor retornado e {double}")
    public void oValorRetornadoE(Double d) {
        assertEquals(taxa, d, 0.01);
    }

}
